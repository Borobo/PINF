<?php

$BDD_host="localhost";
$BDD_user="root";
$BDD_password="";
$BDD_base="dblock4";

?>
