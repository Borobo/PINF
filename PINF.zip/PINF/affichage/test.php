<?php
include("../header.html");
?>

<body>
	<p>BONJOUR JE SUIS UNE PAGE TROP MARRANTE !!</p>
</body>